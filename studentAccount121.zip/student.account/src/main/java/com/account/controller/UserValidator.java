package com.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.account.model.User;
import com.account.service.UserService;

@Component
public class UserValidator implements Validator {
    @Autowired
    private UserService userService;

    @Override
    public boolean supports(Class<?> aClass)
    {
    	System.out.println("supports class");
    	
        return User.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors)
    {
        User user = (User) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "NotEmpty");
        if (user.getUsername().length() < 6 || user.getUsername().length() > 32) 
        {
        	System.out.println("user validator");
            errors.rejectValue("username", "Size.userForm.username");
        }
        
        if (userService.findByUsername(user.getUsername()) != null)
        {
        	System.out.println("user !=nul");
            errors.rejectValue("username", "Duplicate.userForm.username");
        }
        
        String emailPattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "NotEmpty");
        if (user.getEmail().equals(emailPattern)) 
        {
        	System.out.println("email validation");
            errors.rejectValue("email", "Size.userForm.email");
        }
        
        if (userService.findByEmail(user.getEmail()) != null)
        {
        	System.out.println("email !=null");
            errors.rejectValue("email", "Duplicate.userForm.email");
        }
        
        String mobilePattern = "^(1\\-)?[0-9]{3}\\-?[0-9]{3}\\-?[0-9]{4}$";
        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobile", "NotEmpty");
        if (user.getMobile().equals(mobilePattern)) 
        {
        	System.out.println("mobile validation");
            errors.rejectValue("mobile", "Size.userForm.mobile");
        }
        
        if (userService.findByMobile(user.getMobile()) != null)
        {
        	System.out.println("mobile !=null");
            errors.rejectValue("mobile", "Duplicate.userForm.mobile");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty");
        if (user.getPassword().length() < 8 || user.getPassword().length() > 32) 
        {
        	System.out.println("password validation");
            errors.rejectValue("password", "Size.userForm.password");
        }

        if (!user.getPasswordConfirm().equals(user.getPassword())) 
        {
        	System.out.println("password confirm");
            errors.rejectValue("passwordConfirm", "Diff.userForm.passwordConfirm");
        }
    }
}
