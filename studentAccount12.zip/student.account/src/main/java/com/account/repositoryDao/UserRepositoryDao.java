package com.account.repositoryDao;

import com.account.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepositoryDao extends JpaRepository<User, Long> {
    User findByUsername(String username);
}