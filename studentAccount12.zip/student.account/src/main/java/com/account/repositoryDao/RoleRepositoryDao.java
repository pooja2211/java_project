package com.account.repositoryDao;

import com.account.model.Role;
import com.account.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepositoryDao extends JpaRepository<Role, Long>{
}