package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//Student Registration Model Class

@Entity
@Table(name="student_register")
public class Student_RegisterModel implements Serializable
{
	
	private static final long serialVersionUID = -3465813074586302847L;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int stud_id;
	
	@Column 
	private String name;
	
	@Column
	private String email;
	
	@Column
	private String phonenumber;
	
	@Column
	private String password;
	
	//setter & getter Method
		
	public int getStud_id() {
		return stud_id;
	}
	public void setStud_id(int stud_id) {
		this.stud_id = stud_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString()
	{
		return "Student_RegisterModel [stud_id=" + stud_id + ", name=" + name + ", email=" + email + ", phonenumber="
				+ phonenumber + ", password=" + password + "]";
	}
	
	

}
