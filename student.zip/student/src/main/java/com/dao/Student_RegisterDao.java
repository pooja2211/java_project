package com.dao;

import java.util.List;

import com.model.LoginModel;
import com.model.Student_RegisterModel;

public interface Student_RegisterDao 
{

    public void addStudent(Student_RegisterModel student);
    
    public List<Student_RegisterModel> getAllStudents();
        
}
