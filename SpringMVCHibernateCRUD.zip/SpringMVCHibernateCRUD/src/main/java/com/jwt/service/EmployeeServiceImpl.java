package com.jwt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jwt.dao.EmployeeDAO;
import com.jwt.model.Employee;
import com.jwt.model.Registration;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;

	@Override
	@Transactional
	public void addUser(Registration registration) {
		System.out.println("Add user method of service class");

		employeeDAO.addUser(registration);

	}
	
	@Override
	@Transactional
	public List<Registration> getAllUsers()
	{
		return employeeDAO.getAllUsers();
	}
	
	@Override
	@Transactional
	public void addEmployee(Employee employee) {
		employeeDAO.addEmployee(employee);
	}
	
	@Override
	@Transactional
	public List<Employee> getAllEmployees() {
		return employeeDAO.getAllEmployees();
	}

	@Override
	@Transactional
	public void deleteEmployee(Integer employeeId) {
		employeeDAO.deleteEmployee(employeeId);
	}

	public Employee getEmployee(int empid) {
		return employeeDAO.getEmployee(empid);
	}

	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDAO.updateEmployee(employee);
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	public Registration getUser(int userid)
	{
		System.out.println("getuser method of service class");

		return employeeDAO.getUser(userid);
	}
	
	public Registration updateUser(Registration registration)
	{
		System.out.println("update user method of service class");

		// TODO Auto-generated method stub
				return employeeDAO.updateUser(registration);
	}
	
}
