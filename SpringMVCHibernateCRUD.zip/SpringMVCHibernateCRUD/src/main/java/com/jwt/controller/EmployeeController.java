package com.jwt.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jwt.model.Employee;
import com.jwt.model.Registration;
import com.jwt.service.EmployeeService;

@Controller
public class EmployeeController {

	private static final Logger logger = Logger
			.getLogger(EmployeeController.class);

	public EmployeeController() {
		System.out.println("EmployeeController()");
	}

	@Autowired
	private EmployeeService employeeService;

	@RequestMapping(value = "/")
	public ModelAndView listEmployee(ModelAndView model) throws IOException {
		List<Employee> listEmployee = employeeService.getAllEmployees();
		model.addObject("listEmployee", listEmployee);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newEmployee", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Employee employee = new Employee();
		model.addObject("employee", employee);
		model.setViewName("EmployeeForm");
		return model;
	}
	
	@RequestMapping(value = "/")
	public ModelAndView listUser(ModelAndView model) throws IOException {
		List<Registration> listUser = employeeService.getAllUsers();
		model.addObject("listUser", listUser);
		model.setViewName("View_User");
		return model;
	}
	
	@RequestMapping(value = "/newUser", method = RequestMethod.GET)
	public ModelAndView newRegister(ModelAndView model) {
		Registration registration = new Registration();
		model.addObject("registration", registration);
		model.setViewName("Registration");
		return model;
	}
	
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public ModelAndView saveUser(@ModelAttribute Registration registration, final RedirectAttributes redirectAttributes)
	{
		System.out.println("Save user method of controller");
		if (registration.getId() == 0) 
		{ 
			System.out.println("If loop started in Save user method of controller");
			// if employee id is 0 then creating the
			// employee other updating the employee
			employeeService.addUser(registration);
			redirectAttributes.addFlashAttribute("msg","Registration is done successfully.");
			return new ModelAndView("redirect:/");	
		} 
		else 
		{
			System.out.println("Else loop started in Save user method of controller");

			employeeService.updateUser(registration);
			redirectAttributes.addFlashAttribute("msg","Registration is Updated successfully.");
			return new ModelAndView("redirect:/");
		}
		//return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute Employee employee, final RedirectAttributes redirectAttributes)
	{
		if (employee.getId() == 0) 
		{ 
			// if employee id is 0 then creating the
			// employee other updating the employee
			employeeService.addEmployee(employee);
			redirectAttributes.addFlashAttribute("msg","Employee Added successfully.");
			return new ModelAndView("redirect:/");	
		} 
		else 
		{
			employeeService.updateEmployee(employee);
			redirectAttributes.addFlashAttribute("msg","Employee Updated successfully.");
			return new ModelAndView("redirect:/");
		}
		//return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteEmployee", method = RequestMethod.GET)
	public ModelAndView deleteEmployee(HttpServletRequest request, final RedirectAttributes redirectAttributes) 
	{
		int employeeId = Integer.parseInt(request.getParameter("id"));
		employeeService.deleteEmployee(employeeId);
		redirectAttributes.addFlashAttribute("msg","Employee Deleted successfully.");
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/editEmployee", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int employeeId = Integer.parseInt(request.getParameter("id"));
		Employee employee = employeeService.getEmployee(employeeId);
		ModelAndView model = new ModelAndView("EmployeeForm");
		model.addObject("employee", employee);

		return model;
	}

}