package com.jwt.dao;

import java.util.List;
import com.jwt.model.Employee;
import com.jwt.model.Registration;

public interface EmployeeDAO {
	
	public void addUser(Registration registration);
	
	public List<Registration> getAllUsers();

	public void addEmployee(Employee employee);

	public List<Employee> getAllEmployees();

	public void deleteEmployee(Integer employeeId);

	public Employee updateEmployee(Employee employee);

	public Employee getEmployee(int employeeid);
	
	public Registration getUser(int userid);
	
	public Registration updateUser(Registration registration);
}
