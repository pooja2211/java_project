package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Student_RegisterModel;

@Repository	
public class Student_RegisterDaoImpl implements Student_RegisterDao 
{
    @Autowired
    private SessionFactory sessionFactory;

	public void addStudent(Student_RegisterModel student)
	{
		// TODO Auto-generated method stub
		System.out.println("add stud dao1 ()"+student);
	
		sessionFactory.getCurrentSession().saveOrUpdate(student);
		
		System.out.println("add stud dao ()"+student);

	}

	@SuppressWarnings("unchecked")
	public List<Student_RegisterModel> getAllStudents() 
	{
		System.out.println("get all stud ()");
		// TODO Auto-generated method stub
        return sessionFactory.getCurrentSession().createQuery("from Student_RegisterModel").list();
        
	}

}
