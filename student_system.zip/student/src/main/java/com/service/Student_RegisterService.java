package com.service;

import java.util.List;

import com.model.Student_RegisterModel;

public interface Student_RegisterService 
{
	
    public List<Student_RegisterModel> getAllStudents();
    

	public void addStudent(Student_RegisterModel student);
	
	
}
