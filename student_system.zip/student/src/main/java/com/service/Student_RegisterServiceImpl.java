package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.Student_RegisterDao;
import com.model.Student_RegisterModel;

@Service
@Transactional
public class Student_RegisterServiceImpl implements Student_RegisterService
{

	@Autowired
	private Student_RegisterDao stud_RegisterDao;
	
	
	@Transactional
	public void addStudent(Student_RegisterModel student) 
	{
		// TODO Auto-generated method stub
		
		System.out.println("add stud ()");
		
		stud_RegisterDao.addStudent(student);
		
	}

	@Transactional
	public List<Student_RegisterModel> getAllStudents() 
	{
		System.out.println("list all stud method()");
		
		// TODO Auto-generated method stub
		return stud_RegisterDao.getAllStudents();
	}

	
	

}
