package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.model.Student_RegisterModel;
import com.service.Student_RegisterService;

@Controller
public class Student_RegisterController 
{

	private static final Logger logger = Logger.getLogger(Student_RegisterController.class.getName());; 
	
	public Student_RegisterController() 
	{
		System.out.println("Student_RegisterController()");
	}
	
	@Autowired
	private Student_RegisterService studRegisterService;

	@RequestMapping(value = "/students")
	public ModelAndView listStudents(ModelAndView model) throws IOException 
	{
		System.out.println("listStudent()");
		List<Student_RegisterModel> listStudents = studRegisterService.getAllStudents();
		model.addObject("listStudents", listStudents);
		model.setViewName("Student_List");
		return model;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView loginUser(ModelAndView model) 
	{
		System.out.println("login()");
		Student_RegisterModel student = new Student_RegisterModel();
		model.addObject("student", student);
		model.setViewName("Student_Login");
		System.out.println("getting val from stud form"+student);
		return model;
	}
	
	@RequestMapping(value = "/newStudent", method = RequestMethod.GET)
	public ModelAndView newUser(ModelAndView model) 
	{
		System.out.println("newUser()");
		Student_RegisterModel student = new Student_RegisterModel();
		model.addObject("student", student);
		model.setViewName("Student_Registration");
		System.out.println("getting val from stud form"+student);
		return model;
	}
	
	@RequestMapping(value = "/saveStudent", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute Student_RegisterModel student, final RedirectAttributes redirectAttributes)
	{
		System.out.println("save student"+student);
		System.out.println("save student()");
		if (student.getStud_id() == 0) 
		{ 
			System.out.println("Student register"+student);
			// if student id is 0 then creating the student
			studRegisterService.addStudent(student);
			redirectAttributes.addFlashAttribute("msg","Registration is done successfully.");
			//return new ModelAndView("redirect:/");	
		} 
		return new ModelAndView("redirect:/");
	}
	
}
